1. pip install -r requirements.txt
2. python predict_api.py --MESA STON FAKELO PREDICT
3. python -m http.server --MESA STON FAKELO MAP
4. Άνοιξε http://localhost:8000/map.html